python main.py --Qapproximation fourier --num_steps 600000 --filter rec_inside --alpha 0.05 --noise awgn --rnoise 0.0
python main.py --Qapproximation fourier --num_steps 600000 --TDfilter rec_inside --alpha 0.05 --noise awgn --rnoise 0.0
python main.py --Qapproximation fourier --num_steps 600000 --filter rec_inside --TDfilter rec_inside --alpha 0.05 --noise awgn --rnoise 0.0

python main.py --Qapproximation fourier --num_steps 600050 --filter rec_inside --alpha 0.05 --noise awgn --rnoise 0.5
python main.py --Qapproximation fourier --num_steps 600050 --TDfilter rec_inside --alpha 0.05 --noise awgn --rnoise 0.5
python main.py --Qapproximation fourier --num_steps 600050 --filter rec_inside --TDfilter rec_inside --alpha 0.05 --noise awgn --rnoise 0.5

python main.py --Qapproximation fourier --num_steps 600025 --filter rec_inside --alpha 0.05 --noise awgn --rnoise 0.25
python main.py --Qapproximation fourier --num_steps 600025 --TDfilter rec_inside --alpha 0.05 --noise awgn --rnoise 0.25
python main.py --Qapproximation fourier --num_steps 600025 --filter rec_inside --TDfilter rec_inside --alpha 0.05 --noise awgn --rnoise 0.25
